import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { loginUser, registerUser } from '../utils/api';
import './WelcomePage.css';

function WelcomePage({ setUser }) {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      let response;
      if (isLogin) {
        response = await loginUser({ email: formData.email, password: formData.password });
      } else {
        response = await registerUser(formData);
      }

      localStorage.setItem('token', response.token);
      setUser(response.user);
    } catch (error) {
      setError(error.response?.data?.message || 'Authentication failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="welcome-page">
      <div className="welcome-container">
        <motion.div 
          className="welcome-left"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="brand-section">
            <h1 className="brand-name">DEPTH</h1>
            <p className="tagline">Master Data Structures & Algorithms</p>
            <p className="subtitle">Learn, Practice, Excel with AI-Powered Guidance</p>
          </div>

          <div className="features-list">
            <div className="feature-item">
              <span className="feature-icon">✨</span>
              <div>
                <h3>AI-Powered Learning</h3>
                <p>Get personalized help from our AI tutor</p>
              </div>
            </div>
            <div className="feature-item">
              <span className="feature-icon">🎯</span>
              <div>
                <h3>Personalized Roadmap</h3>
                <p>Custom learning path based on your goals</p>
              </div>
            </div>
            <div className="feature-item">
              <span className="feature-icon">📊</span>
              <div>
                <h3>Progress Tracking</h3>
                <p>Monitor your growth and achievements</p>
              </div>
            </div>
            <div className="feature-item">
              <span className="feature-icon">🤖</span>
              <div>
                <h3>24/7 AI Support</h3>
                <p>Never get stuck with instant help</p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div 
          className="welcome-right"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="auth-box">
            <div className="auth-toggle">
              <button 
                className={isLogin ? 'active' : ''} 
                onClick={() => {
                  setIsLogin(true);
                  setError('');
                }}
              >
                Login
              </button>
              <button 
                className={!isLogin ? 'active' : ''} 
                onClick={() => {
                  setIsLogin(false);
                  setError('');
                }}
              >
                Sign Up
              </button>
            </div>

            <form onSubmit={handleSubmit} className="auth-form">
              {!isLogin && (
                <div className="form-group">
                  <label>Full Name</label>
                  <input
                    type="text"
                    name="name"
                    placeholder="Enter your full name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
              )}
              
              <div className="form-group">
                <label>Email</label>
                <input
                  type="email"
                  name="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Password</label>
                <input
                  type="password"
                  name="password"
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  minLength="6"
                />
              </div>
              
              {error && <div className="error-message">{error}</div>}
              
              <button type="submit" className="submit-btn" disabled={loading}>
                {loading ? 'Please wait...' : (isLogin ? 'Login to DEPTH' : 'Create Account')}
              </button>
            </form>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

export default WelcomePage;
