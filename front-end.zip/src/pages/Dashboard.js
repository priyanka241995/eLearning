import React, { useState, useEffect } from 'react';
import SearchBar from '../components/SearchBar';
import CourseList from '../components/CourseList';
import Sidebar from '../components/Sidebar';
import Notification from '../components/Notification';
//import AIChatbot from '../components/AIChatbot';
//import AITutor from '../components/AITutor';
import { getProgress } from '../utils/api';
import './Dashboard.css';

function Dashboard({ user, setUser }) {
  const [searchResults, setSearchResults] = useState([]);
  const [showChatbot, setShowChatbot] = useState(false);
  const [showTutor, setShowTutor] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [progress, setProgress] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    fetchUserProgress();
    loadNotifications();
  }, []);

  const fetchUserProgress = async () => {
    try {
      const data = await getProgress();
      setProgress(data.progress);
    } catch (error) {
      console.error('Error fetching progress:', error);
    }
  };

  const loadNotifications = () => {
    const defaultNotifications = [
      { id: 1, message: `Welcome to DEPTH, ${user.name}! 🚀 Start your DSA journey today`, type: "welcome", read: false },
      { id: 2, message: "Complete your daily task to maintain your streak 🔥", type: "reminder", read: false },
      { id: 3, message: "New course added: Advanced Graph Algorithms 📚", type: "info", read: false }
    ];
    setNotifications(defaultNotifications);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  const markAsRead = (id) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div className="header-left">
          <h1 className="logo">DEPTH</h1>
          <span className="welcome-text">Welcome back, <strong>{user.name}</strong>!</span>
        </div>
        <div className="header-right">
          <button 
            className="notification-btn" 
            onClick={() => setShowNotifications(!showNotifications)}
          >
            🔔
            {unreadCount > 0 && <span className="badge">{unreadCount}</span>}
          </button>
          <button className="logout-btn" onClick={handleLogout}>Logout</button>
        </div>

        {showNotifications && (
          <div className="notifications-dropdown">
            <h3>Notifications</h3>
            {notifications.length === 0 ? (
              <p className="no-notifications">No new notifications</p>
            ) : (
              notifications.map(notif => (
                <div 
                  key={notif.id} 
                  className={`notification-item ${notif.read ? 'read' : ''}`}
                  onClick={() => markAsRead(notif.id)}
                >
                  <p>{notif.message}</p>
                  <span className="notification-time">Just now</span>
                </div>
              ))
            )}
          </div>
        )}
      </header>

      <div className="dashboard-content">
        <main className="main-content">
          <SearchBar setSearchResults={setSearchResults} />
          
          {notifications.filter(n => !n.read).slice(0, 2).map(notif => (
            <Notification 
              key={notif.id} 
              message={notif.message} 
              type={notif.type}
              onClose={() => markAsRead(notif.id)}
            />
          ))}

          {searchResults.length > 0 ? (
            <div className="search-results">
              <h2>Search Results ({searchResults.length})</h2>
              <div className="results-grid">
                {searchResults.map((result, idx) => (
                  <div key={idx} className="result-card">
                    <div className="result-source">{result.source}</div>
                    {result.thumbnail && (
                      <img src={result.thumbnail} alt="" className="result-thumbnail" />
                    )}
                    <h3>{result.title}</h3>
                    <p>{result.description?.substring(0, 150)}...</p>
                    <a href={result.link} target="_blank" rel="noopener noreferrer" className="view-link">
                      View Resource →
                    </a>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <CourseList />
          )}
        </main>

        <Sidebar progress={progress} />
      </div>

      <div className="floating-buttons">
        <button 
          className="ai-btn tutor-btn" 
          onClick={() => setShowTutor(!showTutor)}
          title="AI Tutor"
        >
          🎓
        </button>
        <button 
          className="ai-btn chatbot-btn" 
          onClick={() => setShowChatbot(!showChatbot)}
          title="AI Chatbot"
        >
          💬
        </button>
      </div>

      {/* {showChatbot && <AIChatbot onClose={() => setShowChatbot(false)} />}
      {showTutor && <AITutor onClose={() => setShowTutor(false)} />} */}
    </div>
  );
}

export default Dashboard;

