import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

const getAuthHeader = () => {
  const token = localStorage.getItem('token');
  return { Authorization: `Bearer ${token}` };
};

export const registerUser = async (userData) => {
  const response = await axios.post(`${API_URL}/auth/register`, userData);
  return response.data;
};

export const loginUser = async (credentials) => {
  const response = await axios.post(`${API_URL}/auth/login`, credentials);
  return response.data;
};

export const getUserData = async () => {
  const response = await axios.get(`${API_URL}/auth/me`, {
    headers: getAuthHeader()
  });
  return response.data;
};

export const searchContent = async (query) => {
  const response = await axios.get(`${API_URL}/search?q=${encodeURIComponent(query)}`, {
    headers: getAuthHeader()
  });
  return response.data;
};

export const getCourses = async () => {
  const response = await axios.get(`${API_URL}/courses`, {
    headers: getAuthHeader()
  });
  return response.data;
};

export const getProgress = async () => {
  const response = await axios.get(`${API_URL}/progress`, {
    headers: getAuthHeader()
  });
  return response.data;
};

export const updateProgress = async (topicName) => {
  const response = await axios.post(`${API_URL}/progress/update`, 
    { topicName },
    { headers: getAuthHeader() }
  );
  return response.data;
};
