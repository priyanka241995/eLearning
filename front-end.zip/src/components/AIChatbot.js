import React, { useState, useRef, useEffect } from 'react';
//import './AIChatbot.css';

function AIChatbot({ onClose }) {
  const [messages, setMessages] = useState([
    { 
      type: 'bot', 
      text: 'Hi! I\'m your DSA assistant. Ask me anything about data structures and algorithms!' 
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateResponse = (userMessage) => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('array')) {
      return 'Arrays are fundamental data structures that store elements in contiguous memory locations. They offer O(1) access time but O(n) insertion/deletion. Would you like to know about array operations or common problems?';
    } else if (lowerMessage.includes('time complexity') || lowerMessage.includes('big o')) {
      return 'Time complexity measures how runtime grows with input size. Common complexities: O(1) constant, O(log n) logarithmic, O(n) linear, O(n log n) linearithmic, O(n²) quadratic. What algorithm would you like to analyze?';
    } else if (lowerMessage.includes('linked list')) {
  return 'Linked Lists store data in nodes with pointers. Types: Singly (one direction), Doubly (two directions), Circular.'
    }
}
}