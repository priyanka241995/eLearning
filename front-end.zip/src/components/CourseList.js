import React, { useState, useEffect } from 'react';
import { getCourses } from '../utils/api';
import './CourseList.css';

function CourseList() {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const data = await getCourses();
      setCourses(data.courses);
    } catch (error) {
      console.error('Error fetching courses:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading courses...</div>;
  }

  return (
    <div className="courses-section">
      <h2 className="section-title">Available Courses</h2>
      <div className="courses-grid">
        {courses.map(course => (
          <div key={course._id} className="course-card">
            <div className={`course-badge ${course.level.toLowerCase()}`}>
              {course.level}
            </div>
            <div className="course-icon">📚</div>
            <h3>{course.title}</h3>
            <p>{course.description}</p>
            <div className="course-meta">
              <div className="meta-item">
                <span>📖</span>
                {course.totalTopics || course.topics?.length || 0} Topics
              </div>
              <div className="meta-item">
                <span>⏱️</span>
                {course.duration}
              </div>
            </div>
            <div className="course-rating">
              <span>⭐</span>
              <span>{course.rating || 4.8}</span>
              <span className="enrolled">({course.enrolledStudents || 0} enrolled)</span>
            </div>
            <button className="enroll-btn">Start Learning →</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CourseList;
