import React, { useState } from 'react';
import { searchContent } from '../utils/api';
import './SearchBar.css';

function SearchBar({ setSearchResults }) {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    try {
      const data = await searchContent(query);
      setSearchResults(data.results || []);
    } catch (error) {
      console.error('Search error:', error);
      alert('Search failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="search-container">
      <form onSubmit={handleSearch} className="search-form">
        <div className="search-input-wrapper">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            placeholder="Search DSA topics, tutorials, videos from Google & YouTube..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="search-input"
            disabled={loading}
          />
          <button type="submit" className="search-btn" disabled={loading}>
            {loading ? 'Searching...' : 'Search'}
          </button>
        </div>
      </form>
      <div className="search-suggestions">
        <span>Try:</span>
        <button onClick={() => setQuery('Binary Search')}>Binary Search</button>
        <button onClick={() => setQuery('Dynamic Programming')}>Dynamic Programming</button>
        <button onClick={() => setQuery('Graph Algorithms')}>Graph Algorithms</button>
      </div>
    </div>
  );
}

export default SearchBar;
