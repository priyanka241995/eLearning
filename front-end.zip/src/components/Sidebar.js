import React from 'react';
import './Sidebar.css';

function Sidebar({ progress }) {
  const dsaTopics = [
    { name: "Arrays", completed: progress >= 10 },
    { name: "Linked Lists", completed: progress >= 20 },
    { name: "Stacks", completed: progress >= 30 },
    { name: "Queues", completed: progress >= 40 },
    { name: "Trees", completed: progress >= 50 },
    { name: "Graphs", completed: progress >= 60 },
    { name: "Sorting", completed: progress >= 70 },
    { name: "Searching", completed: progress >= 80 },
    { name: "Dynamic Programming", completed: progress >= 90 },
    { name: "Greedy Algorithms", completed: progress >= 100 }
  ];

  return (
    <aside className="sidebar">
      <div className="sidebar-section">
        <h3 className="sidebar-title">DSA Topics</h3>
        <ul className="topics-list">
          {dsaTopics.map((topic, idx) => (
            <li key={idx} className={topic.completed ? 'completed' : ''}>
              <span className="topic-icon">
                {topic.completed ? '✅' : '⭕'}
              </span>
              <span className="topic-name">{topic.name}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="sidebar-section">
        <h3 className="sidebar-title">Progress Report</h3>
        <div className="progress-container">
          <div className="progress-circle">
            <svg width="140" height="140" viewBox="0 0 140 140">
              <circle
                cx="70"
                cy="70"
                r="60"
                fill="none"
                stroke="#e0e0e0"
                strokeWidth="12"
              />
              <circle
                cx="70"
                cy="70"
                r="60"
                fill="none"
                stroke="url(#gradient)"
                strokeWidth="12"
                strokeDasharray={`${progress * 3.77} 377`}
                strokeLinecap="round"
                transform="rotate(-90 70 70)"
                style={{ transition: 'stroke-dasharray 0.5s ease' }}
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#667eea" />
                  <stop offset="100%" stopColor="#764ba2" />
                </linearGradient>
              </defs>
            </svg>
            <div className="progress-text">
              <span className="progress-percent">{progress}%</span>
              <span className="progress-label">Complete</span>
            </div>
          </div>
        </div>
        <div className="progress-stats">
          <div className="stat-item">
            <span className="stat-value">{Math.round(progress / 10)}</span>
            <span className="stat-label">Topics Done</span>
          </div>
          <div className="stat-item">
            <span className="stat-value">{10 - Math.round(progress / 10)}</span>
            <span className="stat-label">Remaining</span>
          </div>
        </div>
      </div>

      <div className="sidebar-section">
        <h3 className="sidebar-title">Quick Quiz</h3>
        <p className="quiz-description">Test your knowledge daily!</p>
        <button className="quiz-btn">
          <span>🎯</span>
          Start Daily Quiz
        </button>
        <div className="quiz-stats">
          <div className="quiz-stat">
            <span>🔥 3 Day Streak</span>
          </div>
          <div className="quiz-stat">
            <span>✨ 85% Avg Score</span>
          </div>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;