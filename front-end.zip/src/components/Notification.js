import React from 'react';
import './Notification.css';

function Notification({ message, type, onClose }) {
  const getIcon = () => {
    switch(type) {
      case 'welcome': return '👋';
      case 'reminder': return '🔔';
      case 'info': return 'ℹ️';
      case 'success': return '✅';
      default: return '📢';
    }
  };

  return (
    <div className={`notification ${type}`}>
      <span className="notification-icon">{getIcon()}</span>
      <p className="notification-message">{message}</p>
      {onClose && (
        <button className="notification-close" onClick={onClose}>×</button>
      )}
    </div>
  );
}

export default Notification;
